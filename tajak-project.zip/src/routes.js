import Home from "./Pages/Home/Home"

const routes=[
    {path:'/' , element:<Home />},
]

export default routes